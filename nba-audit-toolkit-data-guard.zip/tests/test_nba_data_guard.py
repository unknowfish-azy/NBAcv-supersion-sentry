import unittest

from nba_data_guard import normalize_players, build_sentinel_report, resolve_schedule_context


class NbaDataGuardTests(unittest.TestCase):
    def test_normalize_players(self):
        rows = normalize_players([{"team": "HOU", "name": "Amen Thompson", "jersey": 1,
                                  "player_id": 4684740, "height_in": "79", "position": "G"}], "fixture")
        self.assertEqual(rows[0]["jersey_number"], "1")
        self.assertEqual(rows[0]["identity_features"]["position_group"], "guard")

    def test_duplicate_jersey_blocks(self):
        report = build_sentinel_report([
            {"team": "HOU", "jersey_number": "1", "player_id": "a"},
            {"team": "HOU", "jersey_number": "1", "player_id": "b"}], [])
        self.assertEqual(report["status"], "BLOCK")

    def test_context_unknown_when_no_unique_match(self):
        games = [{"game_id": "g1", "date_utc": "2025-11-04T01:00Z", "home": "HOU", "away": "DAL"}]
        self.assertEqual(resolve_schedule_context(games, "2025-11-05T01:00Z", {"HOU", "DAL"})["status"], "context_unknown")


if __name__ == "__main__":
    unittest.main()
